﻿=== Dark Oxygen Cursor Set ===

By: Vlazteron (http://www.rw-designer.com/user/83361) renatovidal345@gmail.com

Download: http://www.rw-designer.com/cursor-set/oxygen-dark-1

Author's description:

A set of cool Dark Oxygen cursors I hope you enjoy, also this set haves the 15 roles, made by Cursors-4U.
http://www.cursors-4u.com/cursor/2010/12/17/oxygen-black-set.html

==========

License: Custom

You are free:

* To Use the work for personal noncommercial purposes.

For any other use, you must contact the author and ask for permission.